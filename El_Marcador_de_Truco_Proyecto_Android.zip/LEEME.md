# El Marcador de Truco — Android

Este proyecto empaqueta el marcador en una aplicación Android nativa (WebView) y guarda jugadores/historial localmente en el dispositivo.

## Incluye
- Modos 1 vs 1, 2 vs 2 y 3 vs 3.
- Plantel: Salchi, Mango, Stefa, Nicanor, Aguero, Ariel, Chiri, Nico, Lauti, Leo, Tete, Narigon, Juani, Chupa, Bazan y Tutti.
- Tanteador hasta 30, deshacer, nueva partida.
- Historial con fecha, equipos, modalidad y resultado.
- Exportación del historial a TXT.
- Interfaz a pantalla completa y almacenamiento local.

## Cómo obtener el APK sin instalar Android Studio
1. Iniciá sesión o creá una cuenta en GitHub.
2. Creá un repositorio nuevo y subí **todo el contenido de esta carpeta** (incluida la carpeta `.github`).
3. Abrí la pestaña **Actions** del repositorio.
4. Entrá en **Compilar APK Android** y, si hace falta, tocá **Run workflow**.
5. Cuando termine, abrí la ejecución y descargá el artefacto **El-Marcador-de-Truco-APK**.
6. Descomprimí el ZIP descargado y abrí `app-debug.apk` en tu Android para instalarlo. Android puede pedirte que autorices la instalación desde esa fuente.

## Alternativa con Android Studio
Abrí esta carpeta como proyecto existente y ejecutá `assembleDebug`.

## Importante
- Este ZIP es el **proyecto Android listo para compilar**, no un APK ya compilado.
- Los resultados se guardan en el almacenamiento local de la aplicación. Desinstalarla o borrar sus datos puede eliminar el historial.
- El APK generado es de depuración (debug), suficiente para instalar y usar en tu teléfono.
